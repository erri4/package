import requests
import tkinter


blacklist = ['https://www.youtube.com/watch?v=dQw4w9WgXcQ', 'https://www.youtube.com/watch?v=xvFZjo5PgG0']


def openwin():
    pass


def process_packet(packet):
    # Check for HTTP packets
    if 'HTTP' in packet:
        # For HTTP packets, print the URL
        if hasattr(packet.http, 'host') and hasattr(packet.http, 'request_uri'):
            url = f"http://{packet.http.host}{packet.http.request_uri}"
            if isrick(url):
                openwin()
    
    # Check for HTTPS packets (SSL/TLS)
    elif 'TLS' in packet or 'SSL' in packet:
        if hasattr(packet, 'ssl'):
            # Extract SNI field (Server Name Indication) from SSL/TLS handshake
            if hasattr(packet.ssl, 'handshake_extensions_server_name'):
                sni = packet.ssl.handshake_extensions_server_name
                if isrick(sni):
                    openwin()


def isrick(url: str):
    res = requests.get(url)

    page = str(res.text)

    if 'never gonna' in page or 'rick' in page or url in blacklist:
        return True
    return False
