from .blocker import process_packet, blacklist
import argparse
from scapy.all import *
import threading
import os
import pyshark


def start():
    def sniff():
        capture = pyshark.LiveCapture(interface='eth0')
        for packet in capture.sniff_continuously():
            try:
                process_packet(packet)
            except AttributeError as e:
                continue
    background_thread = threading.Thread(target=sniff, daemon=True)
    background_thread.start()


def stop():
    os.system(f'taskkill /f /im rickrollblocker.exe')


def viewblacklist(args):
    if args.add:
        blacklist.append(args.add)
    else:
        for url in blacklist:
            print(url)


def main():
    parser = argparse.ArgumentParser(description="Service management tool.")
    
    subparsers = parser.add_subparsers(help="Available commands", dest="command")

    subparsers.add_parser("stop", help="Stop the service.")

    blacklist_parser = subparsers.add_parser("blacklist", help="Manage the blacklist.")
    blacklist_parser.add_argument("-add", metavar="URL", help="Add a URL to the blacklist.")

    args = parser.parse_args()

    if args.command == "stop":
        stop()
    elif args.command == "blacklist":
        viewblacklist(args)
    elif args.command == None:
        start()
